# Agile Development Project

Our project is a web based application which can be found here: https://medichecker.azurewebsites.net/
